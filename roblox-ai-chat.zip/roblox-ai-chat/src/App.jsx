import RobloxDevChat from './RobloxDevChat'

export default function App() {
  return <RobloxDevChat />
}
